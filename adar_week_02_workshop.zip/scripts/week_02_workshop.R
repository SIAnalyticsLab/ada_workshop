# =================================================================================
# SI ANALYTICS WORKSHOP
# Workshop exercise 2: Data structures in R & Custom functions
# =================================================================================

## NAME: [Firstname Lastname]

# In this workshop, you'll apply your knowledge of data structures, debugging, and creating functions in R.

# There are four sections. The first two sections should be completed together in your group (with one person screen sharing). The last two sections should be completed individually.

# ------------------------------------------------------------------------------
# Learning Objectives
# ------------------------------------------------------------------------------
# By the end of this session, you will be able to:
# - Identify common R data structures.
# - Distinguish between object type and data type.
# - Use `tibble()` to create a clean tabular dataset.
# - Inspect data using `glimpse()` and `head()`.
# - Write custom functions in R.
# - Use `case_when()` to classify values.
# - Apply functions inside `mutate()`.
# - Summarize categorical variables using `count()`.
# - Debug common errors in R code.

# ------------------------------------------------------------------------------
# SETUP
# ------------------------------------------------------------------------------
if(!require(pacman)) install.packages("pacman")
pacman::p_load(tidyverse, here, janitor, outbreaks, readr)

# ================================================================================
# Part 1: Data Structures and Debugging
# ================================================================================

# Create Vectors
ages <- c(28, 34, 29, 45, 23, 38, 31, 40, 27, 50)
names <- c("Ally", "Bob", "Char", "Dav", "Eve", "Fran",
           "Grace", "Han", "Ivy", "Jo")

# Create a Tibble (preferred over data.frame)
survey_df <- tibble(
  Age = ages,
  Name = names
)

# Inspect the Dataset
glimpse(survey_df)
head(survey_df)

# ------------------------------------------------------------
# Exercise 1: Understanding Data Structures
# ------------------------------------------------------------

# Answer the following:

# - What type of object is `ages`?:
# - What data type is each element in `ages`?:
# - What type of data structure is `names`?: 
# - What data type is each element in `names`?:
# - What type of data structure is `survey_df`?: 
# - Why is tibble preferred over data.frame?:


## ============================================================
# Part 2: Functions, Conditionals, and Applying Functions to Data
# ============================================================
# For exercise 2, we will also use an outbreak
# linelist of 136 cases of influenza A H7N9 from a
# 2013 outbreak in China.
#
# This is a modified version of a dataset compiled by
# Kucharski et al. (2014).

# Import the influenza outbreak linelist dataset
flu_linelist <- outbreaks::fluH7N9_china_2013

# View the dataset
flu_linelist

# ------------------------------------------------------------
# Exercise 2: Create an Age Classification Function
# ------------------------------------------------------------

# Write a function called classify_age() to classify age to age group
#
# The function should classify:
#
# • "Below 50" for people younger than 50
# • "50 and above" for people aged 50 and above
#
# After creating the function:
#
# 1. Apply it to the `flu_linelist` dataset
# 2. Create a new column called `age_group`
#
# ------------------------------------------------------------
# HINTS
# ------------------------------------------------------------
#
# • Use function(age) { }
# • Use case_when()
# • Use mutate()
#
# Example structure:
#
# my_function <- function(variable) {
#
#   case_when(
#      condition ~ "label",
#      TRUE ~ "other label"
#   )
#
# }
#
# ------------------------------------------------------------

# Step 1: Create a Practice Vector
# Try your function on this vector first
age_vec <- c(36, 37, 57, 81)

# Step 2: Review the Buggy Function

# The function below contains errors. Do not run it as-is during your final submission. Read it carefully and identify what is wrong.
# ----------------------------------

# Create the function
classify_age <- function(age) {
  
  age <- as.numeric(as.character(age))
  
  case_when(
    age < 50 ~ "Below 50",
    Age >= 50 ~ '50 and above",
    TRUE ~ NA_character_
  )
  
}


#Debugging Questions

1. Which object name is incorrectly capitalized?

**Your answer:**  

2. Which quotation mark is not properly closed?

**Your answer:**  

3. Why would R return an error if this function is run as written?

**Your answer:** 

# ------------------------------------------------------------
# Step 3: Write the Correct Function below, run it to be sure it runs correctly
# ------------------------------------------------------------





# ------------------------------------------------------------
# Step 4: Test your Function on `age_vec`
# ------------------------------------------------------------

classify_age(age_vec)  


# ------------------------------------------------------------
# Step 5: Apply the Function to the Dataset
# ------------------------------------------------------------


# Use `mutate()` to create a new variable called `age_group`.
 
 flu_linelist_clean <- flu_linelist %>% 
  mutate(
    age_group = classify_age(age)
  )
flu_linelist_clean %>% 
  select(age, age_group) %>% 
  head()


# ------------------------------------------------------------
# Step 6: Count the Number of Patients in Each Age Group
# ------------------------------------------------------------
flu_linelist_clean %>% 
  count(age_group)
  
  

# ============================================================
# Part 3: Create a Function to Classify Patient Outcomes
# ============================================================

# In this section, you will create a second function called `classify_outcome()`.
#
# Classification Rules:
# The function should classify patient outcomes using the rules below:

# • "Recovered" if outcome == "Recover"
# • "Died" if outcome == "Death"
# • "Outcome Unknown" for missing outcomes
#
# After creating the function:
#
# 1. Apply it to the `flu_linelist_clean` dataset
# 2. Create a new variable called `outcome_group`
# 3. Count the number of patients in each outcome group
#
# ------------------------------------------------------------
# HINTS
# ------------------------------------------------------------
#
# • Use case_when()
# • Missing values can be checked using is.na()
# • Use mutate() to create new columns
# • Use count() to summarize categories
#
# Example:
#
# is.na(variable)
#
# count(variable_name)
#
# ------------------------------------------------------------

# ------------------------------------------------------------
# Step 1: Inspect the Outcome Variable
# ------------------------------------------------------------

flu_linelist_clean %>% 
  count(outcome)

# ------------------------------------------------------------
# Step 2: Write the Function
# ------------------------------------------------------------

# Complete the function below.
classify_outcome <- function(outcome) {

  case_when(
    outcome == "Recover" ~ "Recovered",
    outcome == "Death" ~ "Died",
    is.na(outcome) ~ "Outcome Unknown",
    TRUE ~ "Outcome Unknown"
  )

}

# ------------------------------------------------------------
# Step 3: Apply the Function to the Dataset
# ------------------------------------------------------------

flu_linelist_clean <- flu_linelist_clean %>% 
  mutate(
    outcome_group = classify_outcome(outcome)
  )

flu_linelist_clean %>% 
  select(outcome, outcome_group) %>% 
  head()

# ------------------------------------------------------------
# Step 4: Count the Number of Patients in Each Outcome Group
# in each outcome group
# ------------------------------------------------------------

flu_linelist_clean %>% 
  count(outcome_group)



# ====================================================================================
# Part 4: Optional Challenge, Combining Functions, Conditionals, and Summarization
# ====================================================================================

# Create a function called risk_category()
#
# Use BOTH age and outcome variables.
#
# Classification Rules:
#
# • "High Risk"
#     Patients aged 60 and above who died
#
# • "Moderate Risk"
#     Patients aged 60 and above who recovered
#
# • "Lower Risk"
#     Patients below 60 years
#
# • "Unknown"
#     Missing age or missing outcome
#
# After creating the function:
#
# 1. Apply it to the dataset
# 2. Create a new variable called risk_group
# 3. Count patients in each risk group
#
# ------------------------------------------------------------
# HINTS
# ------------------------------------------------------------
#
# • Your function will need TWO arguments:
#
#   function(age, outcome)
#
# • Use logical operators:
#
#   &   means AND
#
# Example:
#
# age >= 60 & outcome == "Death"
#
# ------------------------------------------------------------


# Step 1: Write the Risk Classification Function
# ----------------------------------

risk_category <- function(age, outcome) {
  

}



# Step 2: Apply the Function to the Dataset
# ----------------------------------

flu_linelist_clean <- flu_linelist_clean %>% 
  mutate(
    ____ = ______(age, outcome)
  )

flu_linelist_clean %>% 
  select(age, outcome, risk_group) %>% 
  head()




# Step 3: Count Patients in Each Risk Group
# ----------------------------------
flu_linelist_clean %>% 
  ______(risk_group




# ============================================================
# Bonus Reflection Questions
# Answer the questions below in your own words.
# ============================================================

# 1. Why are functions useful in data analysis?
#
# 2. What advantages do functions provide compared to
#    repeatedly writing the same code?
#
# 3. In what real-world situations might grouped
#    classifications like these be useful?
#
# 4. How could these functions be adapted for
#    outbreak surveillance or public health reporting?
#
# ============================================================



# ============================================================
# END OF WORKSHOP
# ============================================================
# Excellent work. You have practiced core R programming concepts that are highly useful in real-world data analysis, including data structures, debugging, functions, conditionals, and applying custom logic to a public health dataset.
  